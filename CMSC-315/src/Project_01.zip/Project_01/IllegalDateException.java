package Project_01;

public class IllegalDateException extends RuntimeException{

	public IllegalDateException(String s) {
		super(s);
	}
}
